/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.4.13-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: college_05
-- ------------------------------------------------------
-- Server version	11.4.13-MariaDB-ubu2404

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `admissions_esgbg`
--

DROP TABLE IF EXISTS `admissions_esgbg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `admissions_esgbg` (
  `campus` smallint(6) NOT NULL DEFAULT 1,
  `student_id` bigint(20) NOT NULL,
  `name` varchar(180) NOT NULL DEFAULT 'not supplied',
  `email` varchar(200) DEFAULT NULL,
  `born` date NOT NULL DEFAULT '0000-00-00',
  `flags` bit(8) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`campus`,`student_id`),
  UNIQUE KEY `email_key` (`email`),
  KEY `name_key` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admissions_esgbg`
--
-- ORDER BY:  `campus`,`student_id`

LOCK TABLES `admissions_esgbg` WRITE;
/*!40000 ALTER TABLE `admissions_esgbg` DISABLE KEYS */;
INSERT INTO `admissions_esgbg` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000005000,'O\'Neil; DROP TABLE fees; -- student 5-0',NULL,'0000-00-00',0x33);
INSERT INTO `admissions_esgbg` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000005001,'line one\nline two\r	tab student 5-1','5.1@college.example.org','2001-02-12',0x5E);
INSERT INTO `admissions_esgbg` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000005002,'zero\0end\Z student 5-2','5.2@college.example.org','2002-02-12',0xD2);
INSERT INTO `admissions_esgbg` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000005003,'back\\slash and \\n literal student 5-3','5.3@college.example.org','2003-02-12',0x3B);
INSERT INTO `admissions_esgbg` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000005004,'emoji 🎓🙂 café 日本語 student 5-4','5.4@college.example.org','2004-02-12',0x95);
INSERT INTO `admissions_esgbg` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000005005,'/* comment */ (one), two; DELIMITER ;; student 5-5','5.5@college.example.org','0000-00-00',0xA3);
INSERT INTO `admissions_esgbg` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000005006,'double \"quote\" and `tick` student 5-6',NULL,'2006-02-12',0x1B);
INSERT INTO `admissions_esgbg` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000005007,'100%_done student 5-7','5.7@college.example.org','2007-02-12',0xE7);
INSERT INTO `admissions_esgbg` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000005008,' student 5-8','5.8@college.example.org','2008-02-12',0x19);
INSERT INTO `admissions_esgbg` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000005009,'O\'Neil; DROP TABLE fees; -- student 5-9','5.9@college.example.org','2009-02-12',0xA0);
INSERT INTO `admissions_esgbg` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000005010,'line one\nline two\r	tab student 5-10','5.10@college.example.org','0000-00-00',0xE3);
INSERT INTO `admissions_esgbg` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000005011,'zero\0end\Z student 5-11','5.11@college.example.org','2001-02-12',0x7B);
INSERT INTO `admissions_esgbg` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000005012,'back\\slash and \\n literal student 5-12',NULL,'2002-02-12',0x0D);
INSERT INTO `admissions_esgbg` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000005013,'emoji 🎓🙂 café 日本語 student 5-13','5.13@college.example.org','2003-02-12',0x22);
INSERT INTO `admissions_esgbg` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000005014,'/* comment */ (one), two; DELIMITER ;; student 5-14','5.14@college.example.org','2004-02-12',0x83);
INSERT INTO `admissions_esgbg` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000005015,'double \"quote\" and `tick` student 5-15','5.15@college.example.org','0000-00-00',0x94);
INSERT INTO `admissions_esgbg` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000005016,'100%_done student 5-16','5.16@college.example.org','2006-02-12',0x72);
INSERT INTO `admissions_esgbg` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000005017,' student 5-17','5.17@college.example.org','2007-02-12',0x94);
INSERT INTO `admissions_esgbg` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000005018,'O\'Neil; DROP TABLE fees; -- student 5-18',NULL,'2008-02-12',0xB8);
INSERT INTO `admissions_esgbg` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000005019,'line one\nline two\r	tab student 5-19','5.19@college.example.org','2009-02-12',0x2D);
INSERT INTO `admissions_esgbg` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000005020,'zero\0end\Z student 5-20','5.20@college.example.org','0000-00-00',0xCD);
INSERT INTO `admissions_esgbg` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000005021,'back\\slash and \\n literal student 5-21','5.21@college.example.org','2001-02-12',0xD6);
INSERT INTO `admissions_esgbg` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000005022,'emoji 🎓🙂 café 日本語 student 5-22','5.22@college.example.org','2002-02-12',0x51);
INSERT INTO `admissions_esgbg` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000005023,'/* comment */ (one), two; DELIMITER ;; student 5-23','5.23@college.example.org','2003-02-12',0x2A);
INSERT INTO `admissions_esgbg` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000005024,'double \"quote\" and `tick` student 5-24',NULL,'2004-02-12',0x55);
INSERT INTO `admissions_esgbg` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000005025,'100%_done student 5-25','5.25@college.example.org','0000-00-00',0xAE);
INSERT INTO `admissions_esgbg` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000005026,' student 5-26','5.26@college.example.org','2006-02-12',0x30);
/*!40000 ALTER TABLE `admissions_esgbg` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_uca1400_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER normalise_name BEFORE UPDATE ON `admissions_esgbg` FOR EACH ROW BEGIN SET NEW.name = TRIM(NEW.name); SET NEW.campus=NEW.campus; END 
*/;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `archive``notes_esgbg`
--

DROP TABLE IF EXISTS `archive``notes_esgbg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `archive``notes_esgbg` (
  `sequence` bigint(20) NOT NULL,
  `section` varchar(30) NOT NULL,
  `comment` longtext DEFAULT NULL,
  `raw` varbinary(200) DEFAULT NULL,
  PRIMARY KEY (`section`,`sequence`),
  UNIQUE KEY `seq_key` (`sequence`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `archive``notes_esgbg`
--
-- ORDER BY:  `section`,`sequence`

LOCK TABLES `archive``notes_esgbg` WRITE;
/*!40000 ALTER TABLE `archive``notes_esgbg` DISABLE KEYS */;
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (0,'hostel-0','O\'Neil; DROP TABLE fees; -- archive 507220005971637',0x00275C1AFF00);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (7,'hostel-0','100%_done archive 568664613896257',0x00275C1AFF07);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (14,'hostel-0','/* comment */ (one), two; DELIMITER ;; archive 881123758151802',0x00275C1AFF0E);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (21,'hostel-0','back\\slash and \\n literal archive 271646478378222',0x00275C1AFF15);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (28,'hostel-0','line one\nline two\r	tab archive 356420444379638',0x00275C1AFF1C);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (35,'hostel-0',' archive 504298073714291',0x00275C1AFF23);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (1,'hostel-1','line one\nline two\r	tab archive 626513289866073',0x00275C1AFF01);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (8,'hostel-1',' archive 105300812544947',0x00275C1AFF08);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (15,'hostel-1','double \"quote\" and `tick` archive 48314514791116',0x00275C1AFF0F);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (22,'hostel-1','emoji 🎓🙂 café 日本語 archive 993944543277069',0x00275C1AFF16);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (29,'hostel-1','zero\0end\Z archive 545735850167498',0x00275C1AFF1D);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (36,'hostel-1','O\'Neil; DROP TABLE fees; -- archive 190848266856759',0x00275C1AFF24);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (2,'hostel-2','zero\0end\Z archive 759897426566373',0x00275C1AFF02);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (9,'hostel-2','O\'Neil; DROP TABLE fees; -- archive 288860163349915',0x00275C1AFF09);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (16,'hostel-2','100%_done archive 238115267567019',0x00275C1AFF10);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (23,'hostel-2','/* comment */ (one), two; DELIMITER ;; archive 836706348640753',0x00275C1AFF17);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (30,'hostel-2','back\\slash and \\n literal archive 702208926430853',0x00275C1AFF1E);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (37,'hostel-2','line one\nline two\r	tab archive 449140451697510',0x00275C1AFF25);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (3,'hostel-3','back\\slash and \\n literal archive 881106521754559',0x00275C1AFF03);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (10,'hostel-3','line one\nline two\r	tab archive 922700441520586',0x00275C1AFF0A);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (17,'hostel-3',' archive 409208036480148',0x00275C1AFF11);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (24,'hostel-3','double \"quote\" and `tick` archive 1123084999370630',0x00275C1AFF18);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (31,'hostel-3','emoji 🎓🙂 café 日本語 archive 493227532975238',0x00275C1AFF1F);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (38,'hostel-3','zero\0end\Z archive 699342488162768',0x00275C1AFF26);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (4,'hostel-4','emoji 🎓🙂 café 日本語 archive 1090968026272643',0x00275C1AFF04);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (11,'hostel-4','zero\0end\Z archive 873866617541642',0x00275C1AFF0B);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (18,'hostel-4','O\'Neil; DROP TABLE fees; -- archive 1069127126339619',0x00275C1AFF12);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (25,'hostel-4','100%_done archive 329269007919707',0x00275C1AFF19);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (32,'hostel-4','/* comment */ (one), two; DELIMITER ;; archive 720256280544349',0x00275C1AFF20);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (39,'hostel-4','back\\slash and \\n literal archive 331302573407223',0x00275C1AFF27);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (5,'hostel-5','/* comment */ (one), two; DELIMITER ;; archive 380605762488062',0x00275C1AFF05);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (12,'hostel-5','back\\slash and \\n literal archive 182557754356185',0x00275C1AFF0C);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (19,'hostel-5','line one\nline two\r	tab archive 888218655228553',0x00275C1AFF13);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (26,'hostel-5',' archive 13758335801634',0x00275C1AFF1A);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (33,'hostel-5','double \"quote\" and `tick` archive 586271992744218',0x00275C1AFF21);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (6,'hostel-6','double \"quote\" and `tick` archive 895935174386752',0x00275C1AFF06);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (13,'hostel-6','emoji 🎓🙂 café 日本語 archive 211388124603806',0x00275C1AFF0D);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (20,'hostel-6','zero\0end\Z archive 285562023678887',0x00275C1AFF14);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (27,'hostel-6','O\'Neil; DROP TABLE fees; -- archive 685727687909525',0x00275C1AFF1B);
INSERT INTO `archive``notes_esgbg` (`sequence`, `section`, `comment`, `raw`) VALUES (34,'hostel-6','100%_done archive 241593132103799',0x00275C1AFF22);
/*!40000 ALTER TABLE `archive``notes_esgbg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `current_students`
--

DROP TABLE IF EXISTS `current_students`;
/*!50001 DROP VIEW IF EXISTS `current_students`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `current_students` AS SELECT
 NULL AS `campus`,
 NULL AS `student_id` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `departments_esgbg`
--

DROP TABLE IF EXISTS `departments_esgbg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `departments_esgbg` (
  `access_bits` bit(32) NOT NULL DEFAULT b'11111111111111111111111111111111',
  `tiny` tinyblob DEFAULT NULL,
  `dept_id` smallint(6) NOT NULL,
  `code` char(12) NOT NULL,
  `balance` decimal(30,8) NOT NULL DEFAULT -1.25000000,
  `signed_edge` bigint(20) NOT NULL,
  `headcount` mediumint(9) NOT NULL DEFAULT -2,
  PRIMARY KEY (`dept_id`),
  UNIQUE KEY `department_code` (`code`),
  KEY `bit_index` (`access_bits`,`headcount`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments_esgbg`
--
-- ORDER BY:  `dept_id`

LOCK TABLES `departments_esgbg` WRITE;
/*!40000 ALTER TABLE `departments_esgbg` DISABLE KEYS */;
INSERT INTO `departments_esgbg` (`access_bits`, `tiny`, `dept_id`, `code`, `balance`, `signed_edge`, `headcount`) VALUES (0xFFFFFFFF,0x00FF275C1A,0,'dept-5-0',9999999999999999999999.12345678,-9223372036854775808,-8388608);
INSERT INTO `departments_esgbg` (`access_bits`, `tiny`, `dept_id`, `code`, `balance`, `signed_edge`, `headcount`) VALUES (0x80000000,0x00FF275C1A,1,'dept-5-1',-9999999999999999999999.87654321,9223372036854775807,8388607);
INSERT INTO `departments_esgbg` (`access_bits`, `tiny`, `dept_id`, `code`, `balance`, `signed_edge`, `headcount`) VALUES (0x00010000,0x00FF275C1A,2,'dept-5-2',0.00000001,-1,-99);
INSERT INTO `departments_esgbg` (`access_bits`, `tiny`, `dept_id`, `code`, `balance`, `signed_edge`, `headcount`) VALUES (0x00000000,0x00FF275C1A,3,'dept-5-3',-0.00000001,0,0);
/*!40000 ALTER TABLE `departments_esgbg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipment_esgbg`
--

DROP TABLE IF EXISTS `equipment_esgbg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipment_esgbg` (
  `description` varchar(80) NOT NULL DEFAULT 'new equipment',
  `raw` mediumblob DEFAULT NULL,
  `ratio` float NOT NULL DEFAULT -0.125,
  `department` char(12) DEFAULT NULL,
  `asset` int(11) NOT NULL,
  PRIMARY KEY (`asset`),
  KEY `asset_department` (`department`),
  CONSTRAINT `asset_department` FOREIGN KEY (`department`) REFERENCES `departments_esgbg` (`code`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipment_esgbg`
--
-- ORDER BY:  `asset`

LOCK TABLES `equipment_esgbg` WRITE;
/*!40000 ALTER TABLE `equipment_esgbg` DISABLE KEYS */;
INSERT INTO `equipment_esgbg` (`description`, `raw`, `ratio`, `department`, `asset`) VALUES ('equipment 5-0',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF,1.25,'dept-5-0',0);
INSERT INTO `equipment_esgbg` (`description`, `raw`, `ratio`, `department`, `asset`) VALUES ('equipment 5-1',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF,-0.125,'dept-5-1',1);
INSERT INTO `equipment_esgbg` (`description`, `raw`, `ratio`, `department`, `asset`) VALUES ('equipment 5-2',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF,1.25,'dept-5-2',2);
INSERT INTO `equipment_esgbg` (`description`, `raw`, `ratio`, `department`, `asset`) VALUES ('equipment 5-3',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF,-0.125,'dept-5-3',3);
/*!40000 ALTER TABLE `equipment_esgbg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exam results_esgbg`
--

DROP TABLE IF EXISTS `exam results_esgbg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `exam results_esgbg` (
  `id` int(11) NOT NULL,
  `book` varchar(40) DEFAULT NULL,
  `term` varchar(20) NOT NULL DEFAULT 'term 1',
  `mark` decimal(12,4) DEFAULT NULL,
  `stamp` timestamp NOT NULL DEFAULT '2020-01-01 00:00:00',
  `duration` time NOT NULL DEFAULT '00:00:00',
  PRIMARY KEY (`id`),
  KEY `exam_book` (`book`),
  KEY `term_key` (`term`,`mark`),
  CONSTRAINT `exam_book` FOREIGN KEY (`book`) REFERENCES `order` (`code`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exam results_esgbg`
--
-- ORDER BY:  `id`

LOCK TABLES `exam results_esgbg` WRITE;
/*!40000 ALTER TABLE `exam results_esgbg` DISABLE KEYS */;
INSERT INTO `exam results_esgbg` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (0,'book-0','term 1',0.1200,'2020-02-12 13:14:15','00:12:34');
INSERT INTO `exam results_esgbg` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (1,'book-1','term 2',1.1200,'2020-02-12 13:14:15','01:12:34');
INSERT INTO `exam results_esgbg` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (2,'book-2','term 3',2.1200,'2020-02-12 13:14:15','02:12:34');
INSERT INTO `exam results_esgbg` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (3,'book-3','term 1',3.1200,'2020-02-12 13:14:15','03:12:34');
INSERT INTO `exam results_esgbg` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (4,'book-4','term 2',4.1200,'2020-02-12 13:14:15','04:12:34');
INSERT INTO `exam results_esgbg` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (5,'book-5','term 3',5.1200,'2020-02-12 13:14:15','05:12:34');
INSERT INTO `exam results_esgbg` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (6,'book-6','term 1',6.1200,'2020-02-12 13:14:15','06:12:34');
INSERT INTO `exam results_esgbg` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (7,'book-7','term 2',7.1200,'2020-02-12 13:14:15','07:12:34');
INSERT INTO `exam results_esgbg` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (8,'book-8','term 3',8.1200,'2020-02-12 13:14:15','08:12:34');
INSERT INTO `exam results_esgbg` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (9,'book-9','term 1',9.1200,'2020-02-12 13:14:15','09:12:34');
INSERT INTO `exam results_esgbg` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (10,'book-10','term 2',10.1200,'2020-02-12 13:14:15','10:12:34');
INSERT INTO `exam results_esgbg` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (11,'book-11','term 3',11.1200,'2020-02-12 13:14:15','11:12:34');
INSERT INTO `exam results_esgbg` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (12,'book-12','term 1',12.1200,'2020-02-12 13:14:15','12:12:34');
INSERT INTO `exam results_esgbg` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (13,'book-13','term 2',13.1200,'2020-02-12 13:14:15','13:12:34');
INSERT INTO `exam results_esgbg` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (14,'book-14','term 3',14.1200,'2020-02-12 13:14:15','14:12:34');
INSERT INTO `exam results_esgbg` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (15,'book-15','term 1',15.1200,'2020-02-12 13:14:15','15:12:34');
INSERT INTO `exam results_esgbg` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (16,'book-16','term 2',16.1200,'2020-02-12 13:14:15','16:12:34');
INSERT INTO `exam results_esgbg` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (17,'book-17','term 3',17.1200,'2020-02-12 13:14:15','17:12:34');
INSERT INTO `exam results_esgbg` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (18,'book-18','term 1',18.1200,'2020-02-12 13:14:15','18:12:34');
INSERT INTO `exam results_esgbg` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (19,'book-19','term 2',19.1200,'2020-02-12 13:14:15','19:12:34');
INSERT INTO `exam results_esgbg` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (20,'book-20','term 3',20.1200,'2020-02-12 13:14:15','20:12:34');
INSERT INTO `exam results_esgbg` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (21,'book-21','term 1',21.1200,'2020-02-12 13:14:15','21:12:34');
INSERT INTO `exam results_esgbg` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (22,'book-22','term 2',22.1200,'2020-02-12 13:14:15','22:12:34');
INSERT INTO `exam results_esgbg` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (23,'book-23','term 3',23.1200,'2020-02-12 13:14:15','23:12:34');
INSERT INTO `exam results_esgbg` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (24,'book-24','term 1',24.1200,'2020-02-12 13:14:15','00:12:34');
INSERT INTO `exam results_esgbg` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (25,'book-25','term 2',25.1200,'2020-02-12 13:14:15','01:12:34');
INSERT INTO `exam results_esgbg` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (26,'book-26','term 3',26.1200,'2020-02-12 13:14:15','02:12:34');
/*!40000 ALTER TABLE `exam results_esgbg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fees_esgbg`
--

DROP TABLE IF EXISTS `fees_esgbg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fees_esgbg` (
  `receipt` int(11) NOT NULL AUTO_INCREMENT,
  `campus` smallint(6) NOT NULL,
  `student_id` bigint(20) NOT NULL,
  `amount` decimal(28,8) NOT NULL DEFAULT 0.00000000,
  `paid_at` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `memo` text DEFAULT NULL,
  PRIMARY KEY (`receipt`),
  UNIQUE KEY `payment_key` (`campus`,`student_id`,`paid_at`),
  KEY `amount_key` (`amount`),
  CONSTRAINT `fee_student` FOREIGN KEY (`campus`, `student_id`) REFERENCES `admissions_esgbg` (`campus`, `student_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fees_esgbg`
--
-- ORDER BY:  `receipt`

LOCK TABLES `fees_esgbg` WRITE;
/*!40000 ALTER TABLE `fees_esgbg` DISABLE KEYS */;
INSERT INTO `fees_esgbg` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (1,1,9000005000,-458705841166221255.28501971,'2026-10-01 12:34:56','O\'Neil; DROP TABLE fees; --');
INSERT INTO `fees_esgbg` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (2,1,9000005001,998362924379541624.56103500,'2026-10-02 12:34:56','line one\nline two\r	tab');
INSERT INTO `fees_esgbg` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (3,1,9000005002,737819244010511728.50043015,'2026-10-03 12:34:56','zero\0end\Z');
INSERT INTO `fees_esgbg` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (4,1,9000005003,-231488061947628766.32613878,'2026-10-04 12:34:56','back\\slash and \\n literal');
INSERT INTO `fees_esgbg` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (5,1,9000005004,740809906342653785.03529663,'2026-10-05 12:34:56','emoji 🎓🙂 café 日本語');
INSERT INTO `fees_esgbg` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (6,1,9000005005,844045654245382649.25214396,'2026-10-06 12:34:56','/* comment */ (one), two; DELIMITER ;;');
INSERT INTO `fees_esgbg` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (7,1,9000005006,-730702610535318826.57659758,'2026-10-07 12:34:56','double \"quote\" and `tick`');
INSERT INTO `fees_esgbg` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (8,1,9000005007,438039658265401371.72749964,'2026-10-08 12:34:56','100%_done');
INSERT INTO `fees_esgbg` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (9,1,9000005008,857056937564475529.65760451,'2026-10-09 12:34:56','');
INSERT INTO `fees_esgbg` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (10,1,9000005009,-718731023045569837.01602539,'2026-10-10 12:34:56','O\'Neil; DROP TABLE fees; --');
INSERT INTO `fees_esgbg` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (11,1,9000005010,512948298484339168.33783613,'2026-10-11 12:34:56','line one\nline two\r	tab');
INSERT INTO `fees_esgbg` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (12,1,9000005011,547378455303109777.84013921,'2026-10-12 12:34:56','zero\0end\Z');
INSERT INTO `fees_esgbg` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (13,1,9000005012,-655200769969653271.22278816,'2026-10-13 12:34:56','back\\slash and \\n literal');
INSERT INTO `fees_esgbg` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (14,1,9000005013,329920345366992424.12042891,'2026-10-14 12:34:56','emoji 🎓🙂 café 日本語');
INSERT INTO `fees_esgbg` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (15,1,9000005014,758567724628922361.29108525,'2026-10-15 12:34:56','/* comment */ (one), two; DELIMITER ;;');
INSERT INTO `fees_esgbg` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (16,1,9000005015,-677362820410094702.53563312,'2026-10-16 12:34:56','double \"quote\" and `tick`');
INSERT INTO `fees_esgbg` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (17,1,9000005016,714808117642095530.73746130,'2026-10-17 12:34:56','100%_done');
INSERT INTO `fees_esgbg` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (18,1,9000005017,115541244939318980.68318797,'2026-10-18 12:34:56','');
INSERT INTO `fees_esgbg` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (19,1,9000005018,-963759015040893080.96912812,'2026-10-19 12:34:56','O\'Neil; DROP TABLE fees; --');
INSERT INTO `fees_esgbg` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (20,1,9000005019,975522918947532890.48315488,'2026-10-20 12:34:56','line one\nline two\r	tab');
INSERT INTO `fees_esgbg` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (21,1,9000005020,299400275388199466.12302971,'2026-10-21 12:34:56','zero\0end\Z');
INSERT INTO `fees_esgbg` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (22,1,9000005021,-582674811454546398.87591348,'2026-10-22 12:34:56','back\\slash and \\n literal');
INSERT INTO `fees_esgbg` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (23,1,9000005022,795812370092986780.38555245,'2026-10-23 12:34:56','emoji 🎓🙂 café 日本語');
INSERT INTO `fees_esgbg` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (24,1,9000005023,245991745422305676.20195274,'2026-10-24 12:34:56','/* comment */ (one), two; DELIMITER ;;');
INSERT INTO `fees_esgbg` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (25,1,9000005024,-571712883876385561.22637065,'2026-10-25 12:34:56','double \"quote\" and `tick`');
INSERT INTO `fees_esgbg` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (26,1,9000005025,286153390000600695.92188195,'2026-10-26 12:34:56','100%_done');
INSERT INTO `fees_esgbg` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (27,1,9000005026,452512065180296716.80790655,'2026-10-27 12:34:56','');
/*!40000 ALTER TABLE `fees_esgbg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hostel counts_esgbg`
--

DROP TABLE IF EXISTS `hostel counts_esgbg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hostel counts_esgbg` (
  `room` int(11) DEFAULT NULL,
  `reading` double NOT NULL DEFAULT 1.25,
  `label` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hostel counts_esgbg`
--

LOCK TABLES `hostel counts_esgbg` WRITE;
/*!40000 ALTER TABLE `hostel counts_esgbg` DISABLE KEYS */;
INSERT INTO `hostel counts_esgbg` (`room`, `reading`, `label`) VALUES (1,1.25,'duplicate');
INSERT INTO `hostel counts_esgbg` (`room`, `reading`, `label`) VALUES (1,1.25,'duplicate');
INSERT INTO `hostel counts_esgbg` (`room`, `reading`, `label`) VALUES (NULL,-0.125,NULL);
INSERT INTO `hostel counts_esgbg` (`room`, `reading`, `label`) VALUES (2,0.00000001,'small');
/*!40000 ALTER TABLE `hostel counts_esgbg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `order` (
  `code` varchar(40) NOT NULL,
  `label` varchar(150) NOT NULL DEFAULT 'book; (new), copy',
  `payload` longblob DEFAULT NULL,
  `signature` binary(8) DEFAULT NULL,
  `note` varchar(200) DEFAULT 'it''s ready',
  `active` tinyint(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`code`),
  UNIQUE KEY `label_key` (`label`),
  KEY `active_key` (`active`,`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order`
--
-- ORDER BY:  `code`

LOCK TABLES `order` WRITE;
/*!40000 ALTER TABLE `order` DISABLE KEYS */;
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-0','Library 5 O\'Neil; DROP TABLE fees; --0',NULL,0x0000000000000000,'zero\0end\Z',0);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-1','Library 5 line one\nline two\r	tab1',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFFB0,0x0101010101010101,'back\\slash and \\n literal',1);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-10','Library 5 line one\nline two\r	tab10',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFFE42ACB12A57EF06AFB7C,0x0A0A0A0A0A0A0A0A,'back\\slash and \\n literal',0);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-11','Library 5 zero\0end\Z11',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF23B13B17A452B757288EC9,0x0B0B0B0B0B0B0B0B,'emoji 🎓🙂 café 日本語',1);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-12','Library 5 back\\slash and \\n literal12',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF59D8EDC3BFF757C9092EFA30,0x0C0C0C0C0C0C0C0C,'/* comment */ (one), two; DELIMITER ;;',0);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-13','Library 5 emoji 🎓🙂 café 日本語13',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFFD735D350696165C38EC7B42C97,0x0D0D0D0D0D0D0D0D,'double \"quote\" and `tick`',1);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-14','Library 5 /* comment */ (one), two; DELIMITER ;;14',NULL,0x0E0E0E0E0E0E0E0E,'100%_done',0);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-15','Library 5 double \"quote\" and `tick`15',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF19A3A03AE8136F5E61B3067FDAF29B,0x0F0F0F0F0F0F0F0F,'',1);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-16','Library 5 100%_done16',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF9EDB1B1FE89249DB9F3F6D23E7C73A7D,0x1010101010101010,'O\'Neil; DROP TABLE fees; --',0);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-17','Library 5 17',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF378FAADD3E25DD427AB69A21F86D0B65DA,0x1111111111111111,'line one\nline two\r	tab',1);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-18','Library 5 O\'Neil; DROP TABLE fees; --18',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFFF6AC54662EEC3068DE557BBC5C1BA9C09D65,0x1212121212121212,'zero\0end\Z',0);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-19','Library 5 line one\nline two\r	tab19',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF2A0AD51CA77E5AEB447906C2D9056A7FE20A1D,0x1313131313131313,'back\\slash and \\n literal',1);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-2','Library 5 zero\0end\Z2',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFFCACB,0x0202020202020202,'emoji 🎓🙂 café 日本語',0);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-20','Library 5 zero\0end\Z20',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF18B6036CACD1684B0ACF40286D4E550E10E0CB04,0x1414141414141414,'emoji 🎓🙂 café 日本語',0);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-21','Library 5 back\\slash and \\n literal21',NULL,0x1515151515151515,'/* comment */ (one), two; DELIMITER ;;',1);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-22','Library 5 emoji 🎓🙂 café 日本語22',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFFBE845CD551EC965501CF42FCB0313B4B52A8A8C41CAA,0x1616161616161616,'double \"quote\" and `tick`',0);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-23','Library 5 /* comment */ (one), two; DELIMITER ;;23',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF1213F2326DEDE3CA1ED12423A5E0DF6C08084D99C9853F,0x1717171717171717,'100%_done',1);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-24','Library 5 double \"quote\" and `tick`24',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF220F6B0EC992680AFB35241912A3BE40AB2EA77FCB0D85A4,0x1818181818181818,'',0);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-25','Library 5 100%_done25',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFFACF810A6407616E4A88FDEF5C266AC28F2DCDC1D5E079578AD,0x1919191919191919,'O\'Neil; DROP TABLE fees; --',1);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-26','Library 5 26',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF9CDF00E0842F2F01E99E1C59B15D3E9D1EE2E0A883E6D2A109F2,0x1A1A1A1A1A1A1A1A,'line one\nline two\r	tab',0);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-3','Library 5 back\\slash and \\n literal3',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF383166,0x0303030303030303,'/* comment */ (one), two; DELIMITER ;;',1);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-4','Library 5 emoji 🎓🙂 café 日本語4',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF256C906F,0x0404040404040404,'double \"quote\" and `tick`',0);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-5','Library 5 /* comment */ (one), two; DELIMITER ;;5',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFFEB7DF68769,0x0505050505050505,'100%_done',1);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-6','Library 5 double \"quote\" and `tick`6',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF47B91C8BB4D2,0x0606060606060606,'',0);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-7','Library 5 100%_done7',NULL,0x0707070707070707,'O\'Neil; DROP TABLE fees; --',1);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-8','Library 5 8',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF1307EBC8740AF099,0x0808080808080808,'line one\nline two\r	tab',0);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-9','Library 5 O\'Neil; DROP TABLE fees; --9',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF939A834600B30A5899,0x0909090909090909,'zero\0end\Z',1);
/*!40000 ALTER TABLE `order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `current_students`
--

/*!50001 DROP VIEW IF EXISTS `current_students`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_uca1400_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `current_students` AS select `admissions_esgbg`.`campus` AS `campus`,`admissions_esgbg`.`student_id` AS `student_id` from `admissions_esgbg` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed
