/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.4.13-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: college_11
-- ------------------------------------------------------
-- Server version	11.4.13-MariaDB-ubu2404

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `admissions_rdcpd`
--

DROP TABLE IF EXISTS `admissions_rdcpd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `admissions_rdcpd` (
  `campus` smallint(6) NOT NULL DEFAULT 1,
  `student_id` bigint(20) NOT NULL,
  `name` varchar(180) NOT NULL DEFAULT 'not supplied',
  `email` varchar(200) DEFAULT NULL,
  `born` date NOT NULL DEFAULT '0000-00-00',
  `flags` bit(8) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`campus`,`student_id`),
  UNIQUE KEY `email_key` (`email`),
  KEY `name_key` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admissions_rdcpd`
--
-- ORDER BY:  `campus`,`student_id`

LOCK TABLES `admissions_rdcpd` WRITE;
/*!40000 ALTER TABLE `admissions_rdcpd` DISABLE KEYS */;
INSERT INTO `admissions_rdcpd` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000011000,'O\'Neil; DROP TABLE fees; -- student 11-0',NULL,'0000-00-00',0x46);
INSERT INTO `admissions_rdcpd` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000011001,'line one\nline two\r	tab student 11-1','11.1@college.example.org','2001-02-12',0xB7);
INSERT INTO `admissions_rdcpd` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000011002,'zero\0end\Z student 11-2','11.2@college.example.org','2002-02-12',0x13);
INSERT INTO `admissions_rdcpd` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000011003,'back\\slash and \\n literal student 11-3','11.3@college.example.org','2003-02-12',0x4B);
INSERT INTO `admissions_rdcpd` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000011004,'emoji 🎓🙂 café 日本語 student 11-4','11.4@college.example.org','2004-02-12',0xEB);
INSERT INTO `admissions_rdcpd` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000011005,'/* comment */ (one), two; DELIMITER ;; student 11-5','11.5@college.example.org','0000-00-00',0x48);
INSERT INTO `admissions_rdcpd` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000011006,'double \"quote\" and `tick` student 11-6',NULL,'2006-02-12',0x24);
INSERT INTO `admissions_rdcpd` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000011007,'100%_done student 11-7','11.7@college.example.org','2007-02-12',0x34);
INSERT INTO `admissions_rdcpd` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000011008,' student 11-8','11.8@college.example.org','2008-02-12',0x58);
INSERT INTO `admissions_rdcpd` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000011009,'O\'Neil; DROP TABLE fees; -- student 11-9','11.9@college.example.org','2009-02-12',0x31);
INSERT INTO `admissions_rdcpd` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000011010,'line one\nline two\r	tab student 11-10','11.10@college.example.org','0000-00-00',0x77);
INSERT INTO `admissions_rdcpd` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000011011,'zero\0end\Z student 11-11','11.11@college.example.org','2001-02-12',0xEB);
INSERT INTO `admissions_rdcpd` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000011012,'back\\slash and \\n literal student 11-12',NULL,'2002-02-12',0x85);
INSERT INTO `admissions_rdcpd` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000011013,'emoji 🎓🙂 café 日本語 student 11-13','11.13@college.example.org','2003-02-12',0x96);
INSERT INTO `admissions_rdcpd` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000011014,'/* comment */ (one), two; DELIMITER ;; student 11-14','11.14@college.example.org','2004-02-12',0x7E);
INSERT INTO `admissions_rdcpd` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000011015,'double \"quote\" and `tick` student 11-15','11.15@college.example.org','0000-00-00',0xAF);
INSERT INTO `admissions_rdcpd` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000011016,'100%_done student 11-16','11.16@college.example.org','2006-02-12',0x88);
INSERT INTO `admissions_rdcpd` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000011017,' student 11-17','11.17@college.example.org','2007-02-12',0x3F);
INSERT INTO `admissions_rdcpd` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000011018,'O\'Neil; DROP TABLE fees; -- student 11-18',NULL,'2008-02-12',0x7A);
INSERT INTO `admissions_rdcpd` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000011019,'line one\nline two\r	tab student 11-19','11.19@college.example.org','2009-02-12',0x07);
INSERT INTO `admissions_rdcpd` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000011020,'zero\0end\Z student 11-20','11.20@college.example.org','0000-00-00',0xBB);
INSERT INTO `admissions_rdcpd` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000011021,'back\\slash and \\n literal student 11-21','11.21@college.example.org','2001-02-12',0xB8);
INSERT INTO `admissions_rdcpd` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000011022,'emoji 🎓🙂 café 日本語 student 11-22','11.22@college.example.org','2002-02-12',0xF3);
INSERT INTO `admissions_rdcpd` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000011023,'/* comment */ (one), two; DELIMITER ;; student 11-23','11.23@college.example.org','2003-02-12',0x3A);
INSERT INTO `admissions_rdcpd` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000011024,'double \"quote\" and `tick` student 11-24',NULL,'2004-02-12',0x01);
INSERT INTO `admissions_rdcpd` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000011025,'100%_done student 11-25','11.25@college.example.org','0000-00-00',0x82);
INSERT INTO `admissions_rdcpd` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000011026,' student 11-26','11.26@college.example.org','2006-02-12',0xA2);
INSERT INTO `admissions_rdcpd` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000011027,'O\'Neil; DROP TABLE fees; -- student 11-27','11.27@college.example.org','2007-02-12',0x7E);
INSERT INTO `admissions_rdcpd` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000011028,'line one\nline two\r	tab student 11-28','11.28@college.example.org','2008-02-12',0x23);
INSERT INTO `admissions_rdcpd` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000011029,'zero\0end\Z student 11-29','11.29@college.example.org','2009-02-12',0xDF);
INSERT INTO `admissions_rdcpd` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000011030,'back\\slash and \\n literal student 11-30',NULL,'0000-00-00',0x2A);
INSERT INTO `admissions_rdcpd` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000011031,'emoji 🎓🙂 café 日本語 student 11-31','11.31@college.example.org','2001-02-12',0x2E);
INSERT INTO `admissions_rdcpd` (`campus`, `student_id`, `name`, `email`, `born`, `flags`) VALUES (1,9000011032,'/* comment */ (one), two; DELIMITER ;; student 11-32','11.32@college.example.org','2002-02-12',0x07);
/*!40000 ALTER TABLE `admissions_rdcpd` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_uca1400_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER normalise_name BEFORE UPDATE ON `admissions_rdcpd` FOR EACH ROW BEGIN SET NEW.name = TRIM(NEW.name); SET NEW.campus=NEW.campus; END 
*/;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `archive``notes_rdcpd`
--

DROP TABLE IF EXISTS `archive``notes_rdcpd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `archive``notes_rdcpd` (
  `sequence` bigint(20) NOT NULL,
  `section` varchar(30) NOT NULL,
  `comment` longtext DEFAULT NULL,
  `raw` varbinary(200) DEFAULT NULL,
  PRIMARY KEY (`section`,`sequence`),
  UNIQUE KEY `seq_key` (`sequence`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `archive``notes_rdcpd`
--
-- ORDER BY:  `section`,`sequence`

LOCK TABLES `archive``notes_rdcpd` WRITE;
/*!40000 ALTER TABLE `archive``notes_rdcpd` DISABLE KEYS */;
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (0,'hostel-0','O\'Neil; DROP TABLE fees; -- archive 1090489825125490',0x00275C1AFF00);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (7,'hostel-0','100%_done archive 34235079713185',0x00275C1AFF07);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (14,'hostel-0','/* comment */ (one), two; DELIMITER ;; archive 660772362527242',0x00275C1AFF0E);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (21,'hostel-0','back\\slash and \\n literal archive 525912026353004',0x00275C1AFF15);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (28,'hostel-0','line one\nline two\r	tab archive 522205011210991',0x00275C1AFF1C);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (35,'hostel-0',' archive 3462845751929',0x00275C1AFF23);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (42,'hostel-0','double \"quote\" and `tick` archive 594727608074244',0x00275C1AFF2A);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (1,'hostel-1','line one\nline two\r	tab archive 904134519398214',0x00275C1AFF01);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (8,'hostel-1',' archive 121960485394421',0x00275C1AFF08);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (15,'hostel-1','double \"quote\" and `tick` archive 406038042865',0x00275C1AFF0F);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (22,'hostel-1','emoji 🎓🙂 café 日本語 archive 840822189421835',0x00275C1AFF16);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (29,'hostel-1','zero\0end\Z archive 906762632836606',0x00275C1AFF1D);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (36,'hostel-1','O\'Neil; DROP TABLE fees; -- archive 179127073340888',0x00275C1AFF24);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (43,'hostel-1','100%_done archive 315161616318498',0x00275C1AFF2B);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (2,'hostel-2','zero\0end\Z archive 354007812663539',0x00275C1AFF02);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (9,'hostel-2','O\'Neil; DROP TABLE fees; -- archive 728012527449240',0x00275C1AFF09);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (16,'hostel-2','100%_done archive 1059444859675311',0x00275C1AFF10);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (23,'hostel-2','/* comment */ (one), two; DELIMITER ;; archive 56715381304738',0x00275C1AFF17);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (30,'hostel-2','back\\slash and \\n literal archive 300184815897241',0x00275C1AFF1E);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (37,'hostel-2','line one\nline two\r	tab archive 931907260350894',0x00275C1AFF25);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (44,'hostel-2',' archive 743436036686209',0x00275C1AFF2C);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (3,'hostel-3','back\\slash and \\n literal archive 301978466507380',0x00275C1AFF03);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (10,'hostel-3','line one\nline two\r	tab archive 714953584479952',0x00275C1AFF0A);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (17,'hostel-3',' archive 903810370478164',0x00275C1AFF11);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (24,'hostel-3','double \"quote\" and `tick` archive 1014643479104086',0x00275C1AFF18);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (31,'hostel-3','emoji 🎓🙂 café 日本語 archive 81624839372189',0x00275C1AFF1F);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (38,'hostel-3','zero\0end\Z archive 838213374020028',0x00275C1AFF26);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (45,'hostel-3','O\'Neil; DROP TABLE fees; -- archive 605312265327251',0x00275C1AFF2D);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (4,'hostel-4','emoji 🎓🙂 café 日本語 archive 794783743254938',0x00275C1AFF04);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (11,'hostel-4','zero\0end\Z archive 781074409444041',0x00275C1AFF0B);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (18,'hostel-4','O\'Neil; DROP TABLE fees; -- archive 157621933052410',0x00275C1AFF12);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (25,'hostel-4','100%_done archive 1270026389028',0x00275C1AFF19);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (32,'hostel-4','/* comment */ (one), two; DELIMITER ;; archive 330592786839378',0x00275C1AFF20);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (39,'hostel-4','back\\slash and \\n literal archive 786837753610321',0x00275C1AFF27);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (5,'hostel-5','/* comment */ (one), two; DELIMITER ;; archive 1115428372948167',0x00275C1AFF05);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (12,'hostel-5','back\\slash and \\n literal archive 562901110485071',0x00275C1AFF0C);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (19,'hostel-5','line one\nline two\r	tab archive 835136340131913',0x00275C1AFF13);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (26,'hostel-5',' archive 667936995192589',0x00275C1AFF1A);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (33,'hostel-5','double \"quote\" and `tick` archive 264109017958162',0x00275C1AFF21);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (40,'hostel-5','emoji 🎓🙂 café 日本語 archive 716054310598022',0x00275C1AFF28);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (6,'hostel-6','double \"quote\" and `tick` archive 390544481542373',0x00275C1AFF06);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (13,'hostel-6','emoji 🎓🙂 café 日本語 archive 680353303829313',0x00275C1AFF0D);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (20,'hostel-6','zero\0end\Z archive 412343200333718',0x00275C1AFF14);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (27,'hostel-6','O\'Neil; DROP TABLE fees; -- archive 1035330882636336',0x00275C1AFF1B);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (34,'hostel-6','100%_done archive 644401499264320',0x00275C1AFF22);
INSERT INTO `archive``notes_rdcpd` (`sequence`, `section`, `comment`, `raw`) VALUES (41,'hostel-6','/* comment */ (one), two; DELIMITER ;; archive 293297723610336',0x00275C1AFF29);
/*!40000 ALTER TABLE `archive``notes_rdcpd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `current_students`
--

DROP TABLE IF EXISTS `current_students`;
/*!50001 DROP VIEW IF EXISTS `current_students`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `current_students` AS SELECT
 NULL AS `campus`,
 NULL AS `student_id` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `departments_rdcpd`
--

DROP TABLE IF EXISTS `departments_rdcpd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `departments_rdcpd` (
  `headcount` mediumint(9) NOT NULL DEFAULT -2,
  `access_bits` bit(32) NOT NULL DEFAULT b'11111111111111111111111111111111',
  `tiny` tinyblob DEFAULT NULL,
  `dept_id` smallint(6) NOT NULL,
  `code` char(12) NOT NULL,
  `balance` decimal(30,8) NOT NULL DEFAULT -1.25000000,
  `signed_edge` bigint(20) NOT NULL,
  PRIMARY KEY (`dept_id`),
  UNIQUE KEY `department_code` (`code`),
  KEY `bit_index` (`access_bits`,`headcount`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments_rdcpd`
--
-- ORDER BY:  `dept_id`

LOCK TABLES `departments_rdcpd` WRITE;
/*!40000 ALTER TABLE `departments_rdcpd` DISABLE KEYS */;
INSERT INTO `departments_rdcpd` (`headcount`, `access_bits`, `tiny`, `dept_id`, `code`, `balance`, `signed_edge`) VALUES (-8388608,0xFFFFFFFF,0x00FF275C1A,0,'dept-11-0',9999999999999999999999.12345678,-9223372036854775808);
INSERT INTO `departments_rdcpd` (`headcount`, `access_bits`, `tiny`, `dept_id`, `code`, `balance`, `signed_edge`) VALUES (8388607,0x80000000,0x00FF275C1A,1,'dept-11-1',-9999999999999999999999.87654321,9223372036854775807);
INSERT INTO `departments_rdcpd` (`headcount`, `access_bits`, `tiny`, `dept_id`, `code`, `balance`, `signed_edge`) VALUES (-99,0x00010000,0x00FF275C1A,2,'dept-11-2',0.00000001,-1);
INSERT INTO `departments_rdcpd` (`headcount`, `access_bits`, `tiny`, `dept_id`, `code`, `balance`, `signed_edge`) VALUES (0,0x00000000,0x00FF275C1A,3,'dept-11-3',-0.00000001,0);
/*!40000 ALTER TABLE `departments_rdcpd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipment_rdcpd`
--

DROP TABLE IF EXISTS `equipment_rdcpd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipment_rdcpd` (
  `description` varchar(80) NOT NULL DEFAULT 'new equipment',
  `raw` mediumblob DEFAULT NULL,
  `ratio` float NOT NULL DEFAULT -0.125,
  `department` char(12) DEFAULT NULL,
  `asset` int(11) NOT NULL,
  PRIMARY KEY (`asset`),
  KEY `asset_department` (`department`),
  CONSTRAINT `asset_department` FOREIGN KEY (`department`) REFERENCES `departments_rdcpd` (`code`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipment_rdcpd`
--
-- ORDER BY:  `asset`

LOCK TABLES `equipment_rdcpd` WRITE;
/*!40000 ALTER TABLE `equipment_rdcpd` DISABLE KEYS */;
INSERT INTO `equipment_rdcpd` (`description`, `raw`, `ratio`, `department`, `asset`) VALUES ('equipment 11-0',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF,1.25,'dept-11-0',0);
INSERT INTO `equipment_rdcpd` (`description`, `raw`, `ratio`, `department`, `asset`) VALUES ('equipment 11-1',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF,-0.125,'dept-11-1',1);
INSERT INTO `equipment_rdcpd` (`description`, `raw`, `ratio`, `department`, `asset`) VALUES ('equipment 11-2',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF,1.25,'dept-11-2',2);
INSERT INTO `equipment_rdcpd` (`description`, `raw`, `ratio`, `department`, `asset`) VALUES ('equipment 11-3',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF,-0.125,'dept-11-3',3);
/*!40000 ALTER TABLE `equipment_rdcpd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exam results_rdcpd`
--

DROP TABLE IF EXISTS `exam results_rdcpd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `exam results_rdcpd` (
  `id` int(11) NOT NULL,
  `book` varchar(40) DEFAULT NULL,
  `term` varchar(20) NOT NULL DEFAULT 'term 1',
  `mark` decimal(12,4) DEFAULT NULL,
  `stamp` timestamp NOT NULL DEFAULT '2020-01-01 00:00:00',
  `duration` time NOT NULL DEFAULT '00:00:00',
  PRIMARY KEY (`id`),
  KEY `exam_book` (`book`),
  KEY `term_key` (`term`,`mark`),
  CONSTRAINT `exam_book` FOREIGN KEY (`book`) REFERENCES `order` (`code`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exam results_rdcpd`
--
-- ORDER BY:  `id`

LOCK TABLES `exam results_rdcpd` WRITE;
/*!40000 ALTER TABLE `exam results_rdcpd` DISABLE KEYS */;
INSERT INTO `exam results_rdcpd` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (0,'book-0','term 1',0.1200,'2020-02-12 13:14:15','00:12:34');
INSERT INTO `exam results_rdcpd` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (1,'book-1','term 2',1.1200,'2020-02-12 13:14:15','01:12:34');
INSERT INTO `exam results_rdcpd` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (2,'book-2','term 3',2.1200,'2020-02-12 13:14:15','02:12:34');
INSERT INTO `exam results_rdcpd` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (3,'book-3','term 1',3.1200,'2020-02-12 13:14:15','03:12:34');
INSERT INTO `exam results_rdcpd` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (4,'book-4','term 2',4.1200,'2020-02-12 13:14:15','04:12:34');
INSERT INTO `exam results_rdcpd` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (5,'book-5','term 3',5.1200,'2020-02-12 13:14:15','05:12:34');
INSERT INTO `exam results_rdcpd` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (6,'book-6','term 1',6.1200,'2020-02-12 13:14:15','06:12:34');
INSERT INTO `exam results_rdcpd` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (7,'book-7','term 2',7.1200,'2020-02-12 13:14:15','07:12:34');
INSERT INTO `exam results_rdcpd` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (8,'book-8','term 3',8.1200,'2020-02-12 13:14:15','08:12:34');
INSERT INTO `exam results_rdcpd` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (9,'book-9','term 1',9.1200,'2020-02-12 13:14:15','09:12:34');
INSERT INTO `exam results_rdcpd` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (10,'book-10','term 2',10.1200,'2020-02-12 13:14:15','10:12:34');
INSERT INTO `exam results_rdcpd` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (11,'book-11','term 3',11.1200,'2020-02-12 13:14:15','11:12:34');
INSERT INTO `exam results_rdcpd` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (12,'book-12','term 1',12.1200,'2020-02-12 13:14:15','12:12:34');
INSERT INTO `exam results_rdcpd` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (13,'book-13','term 2',13.1200,'2020-02-12 13:14:15','13:12:34');
INSERT INTO `exam results_rdcpd` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (14,'book-14','term 3',14.1200,'2020-02-12 13:14:15','14:12:34');
INSERT INTO `exam results_rdcpd` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (15,'book-15','term 1',15.1200,'2020-02-12 13:14:15','15:12:34');
INSERT INTO `exam results_rdcpd` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (16,'book-16','term 2',16.1200,'2020-02-12 13:14:15','16:12:34');
INSERT INTO `exam results_rdcpd` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (17,'book-17','term 3',17.1200,'2020-02-12 13:14:15','17:12:34');
INSERT INTO `exam results_rdcpd` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (18,'book-18','term 1',18.1200,'2020-02-12 13:14:15','18:12:34');
INSERT INTO `exam results_rdcpd` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (19,'book-19','term 2',19.1200,'2020-02-12 13:14:15','19:12:34');
INSERT INTO `exam results_rdcpd` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (20,'book-20','term 3',20.1200,'2020-02-12 13:14:15','20:12:34');
INSERT INTO `exam results_rdcpd` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (21,'book-21','term 1',21.1200,'2020-02-12 13:14:15','21:12:34');
INSERT INTO `exam results_rdcpd` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (22,'book-22','term 2',22.1200,'2020-02-12 13:14:15','22:12:34');
INSERT INTO `exam results_rdcpd` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (23,'book-23','term 3',23.1200,'2020-02-12 13:14:15','23:12:34');
INSERT INTO `exam results_rdcpd` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (24,'book-24','term 1',24.1200,'2020-02-12 13:14:15','00:12:34');
INSERT INTO `exam results_rdcpd` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (25,'book-25','term 2',25.1200,'2020-02-12 13:14:15','01:12:34');
INSERT INTO `exam results_rdcpd` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (26,'book-26','term 3',26.1200,'2020-02-12 13:14:15','02:12:34');
INSERT INTO `exam results_rdcpd` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (27,'book-27','term 1',27.1200,'2020-02-12 13:14:15','03:12:34');
INSERT INTO `exam results_rdcpd` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (28,'book-28','term 2',28.1200,'2020-02-12 13:14:15','04:12:34');
INSERT INTO `exam results_rdcpd` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (29,'book-29','term 3',29.1200,'2020-02-12 13:14:15','05:12:34');
INSERT INTO `exam results_rdcpd` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (30,'book-30','term 1',30.1200,'2020-02-12 13:14:15','06:12:34');
INSERT INTO `exam results_rdcpd` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (31,'book-31','term 2',31.1200,'2020-02-12 13:14:15','07:12:34');
INSERT INTO `exam results_rdcpd` (`id`, `book`, `term`, `mark`, `stamp`, `duration`) VALUES (32,'book-32','term 3',32.1200,'2020-02-12 13:14:15','08:12:34');
/*!40000 ALTER TABLE `exam results_rdcpd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fees_rdcpd`
--

DROP TABLE IF EXISTS `fees_rdcpd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fees_rdcpd` (
  `receipt` int(11) NOT NULL AUTO_INCREMENT,
  `campus` smallint(6) NOT NULL,
  `student_id` bigint(20) NOT NULL,
  `amount` decimal(28,8) NOT NULL DEFAULT 0.00000000,
  `paid_at` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `memo` text DEFAULT NULL,
  PRIMARY KEY (`receipt`),
  UNIQUE KEY `payment_key` (`campus`,`student_id`,`paid_at`),
  KEY `amount_key` (`amount`),
  CONSTRAINT `fee_student` FOREIGN KEY (`campus`, `student_id`) REFERENCES `admissions_rdcpd` (`campus`, `student_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fees_rdcpd`
--
-- ORDER BY:  `receipt`

LOCK TABLES `fees_rdcpd` WRITE;
/*!40000 ALTER TABLE `fees_rdcpd` DISABLE KEYS */;
INSERT INTO `fees_rdcpd` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (1,1,9000011000,-459889159832291247.32600160,'2026-10-01 12:34:56','O\'Neil; DROP TABLE fees; --');
INSERT INTO `fees_rdcpd` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (2,1,9000011001,184098337023073153.74291958,'2026-10-02 12:34:56','line one\nline two\r	tab');
INSERT INTO `fees_rdcpd` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (3,1,9000011002,954444103966706858.15997396,'2026-10-03 12:34:56','zero\0end\Z');
INSERT INTO `fees_rdcpd` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (4,1,9000011003,-954101097898641213.23346331,'2026-10-04 12:34:56','back\\slash and \\n literal');
INSERT INTO `fees_rdcpd` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (5,1,9000011004,264367868611189329.63441536,'2026-10-05 12:34:56','emoji 🎓🙂 café 日本語');
INSERT INTO `fees_rdcpd` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (6,1,9000011005,229867469781874880.58276255,'2026-10-06 12:34:56','/* comment */ (one), two; DELIMITER ;;');
INSERT INTO `fees_rdcpd` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (7,1,9000011006,-137608489910126997.36272998,'2026-10-07 12:34:56','double \"quote\" and `tick`');
INSERT INTO `fees_rdcpd` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (8,1,9000011007,181619816181573655.34007567,'2026-10-08 12:34:56','100%_done');
INSERT INTO `fees_rdcpd` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (9,1,9000011008,764769686764507197.69689504,'2026-10-09 12:34:56','');
INSERT INTO `fees_rdcpd` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (10,1,9000011009,-313243840315265958.21296999,'2026-10-10 12:34:56','O\'Neil; DROP TABLE fees; --');
INSERT INTO `fees_rdcpd` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (11,1,9000011010,455779110963788687.82338040,'2026-10-11 12:34:56','line one\nline two\r	tab');
INSERT INTO `fees_rdcpd` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (12,1,9000011011,382820763449695371.77722219,'2026-10-12 12:34:56','zero\0end\Z');
INSERT INTO `fees_rdcpd` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (13,1,9000011012,-772359707493518139.15787725,'2026-10-13 12:34:56','back\\slash and \\n literal');
INSERT INTO `fees_rdcpd` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (14,1,9000011013,183602494165057054.24307031,'2026-10-14 12:34:56','emoji 🎓🙂 café 日本語');
INSERT INTO `fees_rdcpd` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (15,1,9000011014,177934472539674047.72744969,'2026-10-15 12:34:56','/* comment */ (one), two; DELIMITER ;;');
INSERT INTO `fees_rdcpd` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (16,1,9000011015,-310315951187817233.06955771,'2026-10-16 12:34:56','double \"quote\" and `tick`');
INSERT INTO `fees_rdcpd` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (17,1,9000011016,766671299444739287.73291414,'2026-10-17 12:34:56','100%_done');
INSERT INTO `fees_rdcpd` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (18,1,9000011017,850015904510635341.49938039,'2026-10-18 12:34:56','');
INSERT INTO `fees_rdcpd` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (19,1,9000011018,-129270839970343326.37586930,'2026-10-19 12:34:56','O\'Neil; DROP TABLE fees; --');
INSERT INTO `fees_rdcpd` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (20,1,9000011019,355500147358427874.30956188,'2026-10-20 12:34:56','line one\nline two\r	tab');
INSERT INTO `fees_rdcpd` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (21,1,9000011020,871052014764506819.97796820,'2026-10-21 12:34:56','zero\0end\Z');
INSERT INTO `fees_rdcpd` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (22,1,9000011021,-403010039443108984.73756141,'2026-10-22 12:34:56','back\\slash and \\n literal');
INSERT INTO `fees_rdcpd` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (23,1,9000011022,172922845264741730.56960214,'2026-10-23 12:34:56','emoji 🎓🙂 café 日本語');
INSERT INTO `fees_rdcpd` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (24,1,9000011023,615685071234359044.73953846,'2026-10-24 12:34:56','/* comment */ (one), two; DELIMITER ;;');
INSERT INTO `fees_rdcpd` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (25,1,9000011024,-695121990882429592.00103117,'2026-10-25 12:34:56','double \"quote\" and `tick`');
INSERT INTO `fees_rdcpd` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (26,1,9000011025,906403322819391312.86234574,'2026-10-26 12:34:56','100%_done');
INSERT INTO `fees_rdcpd` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (27,1,9000011026,881859745464342640.68914325,'2026-10-27 12:34:56','');
INSERT INTO `fees_rdcpd` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (28,1,9000011027,-654304250959398198.65432829,'2026-10-28 12:34:56','O\'Neil; DROP TABLE fees; --');
INSERT INTO `fees_rdcpd` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (29,1,9000011028,425751001749585676.83895827,'2026-10-01 12:34:56','line one\nline two\r	tab');
INSERT INTO `fees_rdcpd` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (30,1,9000011029,106965823174472557.31026379,'2026-10-02 12:34:56','zero\0end\Z');
INSERT INTO `fees_rdcpd` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (31,1,9000011030,-706165550748770762.80912114,'2026-10-03 12:34:56','back\\slash and \\n literal');
INSERT INTO `fees_rdcpd` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (32,1,9000011031,108775175778797559.07797643,'2026-10-04 12:34:56','emoji 🎓🙂 café 日本語');
INSERT INTO `fees_rdcpd` (`receipt`, `campus`, `student_id`, `amount`, `paid_at`, `memo`) VALUES (33,1,9000011032,256078388090163724.23947508,'2026-10-05 12:34:56','/* comment */ (one), two; DELIMITER ;;');
/*!40000 ALTER TABLE `fees_rdcpd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hostel counts_rdcpd`
--

DROP TABLE IF EXISTS `hostel counts_rdcpd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hostel counts_rdcpd` (
  `room` int(11) DEFAULT NULL,
  `reading` double NOT NULL DEFAULT 1.25,
  `label` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hostel counts_rdcpd`
--

LOCK TABLES `hostel counts_rdcpd` WRITE;
/*!40000 ALTER TABLE `hostel counts_rdcpd` DISABLE KEYS */;
INSERT INTO `hostel counts_rdcpd` (`room`, `reading`, `label`) VALUES (1,1.25,'duplicate');
INSERT INTO `hostel counts_rdcpd` (`room`, `reading`, `label`) VALUES (1,1.25,'duplicate');
INSERT INTO `hostel counts_rdcpd` (`room`, `reading`, `label`) VALUES (NULL,-0.125,NULL);
INSERT INTO `hostel counts_rdcpd` (`room`, `reading`, `label`) VALUES (2,0.00000001,'small');
/*!40000 ALTER TABLE `hostel counts_rdcpd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `order` (
  `code` varchar(40) NOT NULL,
  `label` varchar(150) NOT NULL DEFAULT 'book; (new), copy',
  `payload` longblob DEFAULT NULL,
  `signature` binary(8) DEFAULT NULL,
  `note` varchar(200) DEFAULT 'it''s ready',
  `active` tinyint(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`code`),
  UNIQUE KEY `label_key` (`label`),
  KEY `active_key` (`active`,`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order`
--
-- ORDER BY:  `code`

LOCK TABLES `order` WRITE;
/*!40000 ALTER TABLE `order` DISABLE KEYS */;
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-0','Library 11 O\'Neil; DROP TABLE fees; --0',NULL,0x0000000000000000,'zero\0end\Z',0);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-1','Library 11 line one\nline two\r	tab1',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF6A,0x0101010101010101,'back\\slash and \\n literal',1);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-10','Library 11 line one\nline two\r	tab10',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFFCADD0523517DD84F973A,0x0A0A0A0A0A0A0A0A,'back\\slash and \\n literal',0);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-11','Library 11 zero\0end\Z11',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF21E50C09CCAA0D78B20AE5,0x0B0B0B0B0B0B0B0B,'emoji 🎓🙂 café 日本語',1);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-12','Library 11 back\\slash and \\n literal12',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF17EE40E8A3515FC812D0791E,0x0C0C0C0C0C0C0C0C,'/* comment */ (one), two; DELIMITER ;;',0);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-13','Library 11 emoji 🎓🙂 café 日本語13',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF3440B19E11ECFDF19DA7A7E17B,0x0D0D0D0D0D0D0D0D,'double \"quote\" and `tick`',1);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-14','Library 11 /* comment */ (one), two; DELIMITER ;;14',NULL,0x0E0E0E0E0E0E0E0E,'100%_done',0);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-15','Library 11 double \"quote\" and `tick`15',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF0848F2F07405196C74B5823FBB613F,0x0F0F0F0F0F0F0F0F,'',1);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-16','Library 11 100%_done16',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFFEF2B341CCFB7D62B8B023C4E2BBC00E1,0x1010101010101010,'O\'Neil; DROP TABLE fees; --',0);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-17','Library 11 17',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF573505F4FAD4B7CDA533FB5F5B08AD16FE,0x1111111111111111,'line one\nline two\r	tab',1);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-18','Library 11 O\'Neil; DROP TABLE fees; --18',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF643F2753D32285FB4E0918120F6940D2F786,0x1212121212121212,'zero\0end\Z',0);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-19','Library 11 line one\nline two\r	tab19',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF17F1170E0D44E8CA261C7E4D04D394FA09A004,0x1313131313131313,'back\\slash and \\n literal',1);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-2','Library 11 zero\0end\Z2',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF3765,0x0202020202020202,'emoji 🎓🙂 café 日本語',0);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-20','Library 11 zero\0end\Z20',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF91722ADA07F6BB7BE90A6C5082129F1CC9CA8A77,0x1414141414141414,'emoji 🎓🙂 café 日本語',0);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-21','Library 11 back\\slash and \\n literal21',NULL,0x1515151515151515,'/* comment */ (one), two; DELIMITER ;;',1);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-22','Library 11 emoji 🎓🙂 café 日本語22',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFFF0B290B50F7CE8D9B3BCC267E9F7C6E7E4B94F06ADAB,0x1616161616161616,'double \"quote\" and `tick`',0);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-23','Library 11 /* comment */ (one), two; DELIMITER ;;23',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFFD429C8C2D9E597E4F607521FF1925AB9DC8859246C370E,0x1717171717171717,'100%_done',1);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-24','Library 11 double \"quote\" and `tick`24',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFFCDF0E75E91C2764382A11B098545C2201DE5E30DECF6EBC7,0x1818181818181818,'',0);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-25','Library 11 100%_done25',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFFC99A8AA764AD8D39A3528E9F6A9F8DF20E24D9B4466CE5DCE7,0x1919191919191919,'O\'Neil; DROP TABLE fees; --',1);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-26','Library 11 26',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFFB3C36C4951032F090FF1B29E58CE565D6DBCBB2AB7C26F87057F,0x1A1A1A1A1A1A1A1A,'line one\nline two\r	tab',0);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-27','Library 11 O\'Neil; DROP TABLE fees; --27',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF921D8FF93EC53CED82822E0EDEF8C01A1D01734B7C3BA8E13B7AC7,0x1B1B1B1B1B1B1B1B,'zero\0end\Z',1);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-28','Library 11 line one\nline two\r	tab28',NULL,0x1C1C1C1C1C1C1C1C,'back\\slash and \\n literal',0);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-29','Library 11 zero\0end\Z29',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFFCA25D1A7B7B6560D004D843E94A0196589FC6C2AAD2D92E0134EC83DCB,0x1D1D1D1D1D1D1D1D,'emoji 🎓🙂 café 日本語',1);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-3','Library 11 back\\slash and \\n literal3',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF2AA1F0,0x0303030303030303,'/* comment */ (one), two; DELIMITER ;;',1);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-30','Library 11 back\\slash and \\n literal30',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFFCD21FE9CE5E5585EE00EFCCC90F47BEFDC70FF194E0B51A7B66EA59B0CE4,0x1E1E1E1E1E1E1E1E,'/* comment */ (one), two; DELIMITER ;;',0);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-31','Library 11 emoji 🎓🙂 café 日本語31',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF9C7B765512E0A48B8CA502430DFD8493FB66BC4B727E52ACD90EE1DF92EE6C,0x1F1F1F1F1F1F1F1F,'double \"quote\" and `tick`',1);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-32','Library 11 /* comment */ (one), two; DELIMITER ;;32',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFFF584AEB96FD473528681C6B4FF603B47513D3B176AEB65FC1ED145BC990494E4,0x2020202020202020,'100%_done',0);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-4','Library 11 emoji 🎓🙂 café 日本語4',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFFC5F119B6,0x0404040404040404,'double \"quote\" and `tick`',0);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-5','Library 11 /* comment */ (one), two; DELIMITER ;;5',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFFF90BAA865E,0x0505050505050505,'100%_done',1);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-6','Library 11 double \"quote\" and `tick`6',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF18FEEF49AD94,0x0606060606060606,'',0);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-7','Library 11 100%_done7',NULL,0x0707070707070707,'O\'Neil; DROP TABLE fees; --',1);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-8','Library 11 8',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFFAD78CAC3B8EDCC9C,0x0808080808080808,'line one\nline two\r	tab',0);
INSERT INTO `order` (`code`, `label`, `payload`, `signature`, `note`, `active`) VALUES ('book-9','Library 11 O\'Neil; DROP TABLE fees; --9',0x000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122232425262728292A2B2C2D2E2F303132333435363738393A3B3C3D3E3F404142434445464748494A4B4C4D4E4F505152535455565758595A5B5C5D5E5F606162636465666768696A6B6C6D6E6F707172737475767778797A7B7C7D7E7F808182838485868788898A8B8C8D8E8F909192939495969798999A9B9C9D9E9FA0A1A2A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4B5B6B7B8B9BABBBCBDBEBFC0C1C2C3C4C5C6C7C8C9CACBCCCDCECFD0D1D2D3D4D5D6D7D8D9DADBDCDDDEDFE0E1E2E3E4E5E6E7E8E9EAEBECEDEEEFF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF4D253C01F85F0EB5A0,0x0909090909090909,'zero\0end\Z',1);
/*!40000 ALTER TABLE `order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `current_students`
--

/*!50001 DROP VIEW IF EXISTS `current_students`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_uca1400_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `current_students` AS select `admissions_rdcpd`.`campus` AS `campus`,`admissions_rdcpd`.`student_id` AS `student_id` from `admissions_rdcpd` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed
